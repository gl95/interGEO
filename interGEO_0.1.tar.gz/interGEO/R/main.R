#' @title iGEO
#' @description Main function. Launches the GUI and all other functions are called by this one.
#' @details 
#' The left panel shows all the GEO "series matrices" available in workspace. By selecting one of those series matrices, a list of all the related expression-data matrices appears in the right panel. Association series matrix-data is performed according to column name matches. The dimension of the data matrix (which can be different from the raw one obtained from exprs(series.matrix)) is shown. Data objects can even contain factors in some rows. It will be an important feature in the "WORKONDATA" option. Each time you select an object, such object moves at the top of its panel.
#' \cr \cr
#' Import series matrices with the "LOAD DATASET" option. It launches {getGSE} function. If the name does not correspond to any dataset in GEO, an error message is launched, but the program keeps running! If a GSE file contains many series matrices, all of them are imported. You can rename each series matrix.
#' \cr \cr
#' Create a new expression-data matrix associated to selected dataset with the "CREATE DATA" option. It launches getData function. If no series matrix is either selected or available, an error message is launched, but the program keeps running!
#' \cr \cr
#' Delete a series matrix with the "DELETE SM" option. It launches deleteGSE function. If no series matrix is either selected or available, an error message is launched, but the program keeps running!
#' \cr \cr
#' Perform basic preliminary operations on data with the "WORK ON DATA" option. It launches workonData function. If no data is either selected or available, an error message is launched, but the program keeps running!
#' \cr \cr
#' Scale data column with  with the "WORK ON DATA" option. It launches scaleData function. It is not a simple scale function from the {Base} library, because of the fact that data matrices can also contain factors in some rows. If no data is either selected or available, an error message is launched, but the program keeps running!
#' \cr \cr
#' Delete an expression-data matrix with the "DELETE DATA" option. It launches deleteData function. If no data is either selected or available, an error message is launched, but the program keeps running!
#' @export
iGEO <- function(){
  # DEFINE LOCAL ENVIRONMENT
  env <- environment()
  # LOCAL TASK FLAG
  task <- 0
  # INITIALIZATION
  is.mat.sel<-0
  
  ###################################################################
  
  # RETRIEVE ALL THE VARIABLE NAMES ON WORKSPACE
  GLOB <- names(as.list(.GlobalEnv))
  # LIST OF GSE-LIKE VARIABLE NAMES
  GSE <- c()
  # LIST OF MATRIX-LIKE VARIABLE NAMES
  MAT.RAW <- c()
  for(var in GLOB){
    if(class(get(var,envir=.GlobalEnv))[1]=='ExpressionSet')
      GSE <- c(GSE,var)
    if(class(get(var,envir=.GlobalEnv))[1]=='matrix'|
       class(get(var,envir=.GlobalEnv))[1]=='data.frame')
      MAT.RAW <- c(MAT.RAW,var)
  }
  # LIST OF EXPRESSION-DATA VARIABLE NAMES
  MAT <- list()
  # ASSOCIATE A LIST OF COLNAMES TO EVERY GSE
  # ASSOCIATE A LIST OF EXPRESSION-DATA TO EVERY GSE
  for(gse in GSE){
    GSE.COL <- colnames(get(gse,envir=.GlobalEnv))
    GSE.MAT <- c()
    for(mat in MAT.RAW){
      col <- colnames(get(mat,envir=.GlobalEnv))[1]
      if(!is.null(col))
        if(sum(GSE.COL==col))
          GSE.MAT <- c(GSE.MAT,mat)
    }
    MAT[[gse]]<-GSE.MAT
  }
  
  ###################################################################
  
  # BUILD GUI
  win.main <- tcltk::tktoplevel()
  tcltk::tktitle(win.main)<-'interGEO - v 0.1'
  # GRAPHICAL ISSUES
  font.top <- tcltk::tkfont.create(weight="bold",slant="italic")
  font.big <- tcltk::tkfont.create(weight="bold")
  mycolor<-'SystemMenu'
  # INITIALIZE ENTRIES VARIABLES
  id <- tcltk::tclVar(init='GSE1000')
  # INITIALIZE STRUCTURES YOU DON'T HAVE TO UPLOAD PERIODICALLY
  labe1 <- tcltk::tklabel(win.main,text="choose series matrix",font = font.top,justify="center")
  entry <- tcltk::tkentry(win.main,width='25',textvariable = id)
  butt1 <- tcltk::tkbutton(win.main,width = 17,text="LOAD DATASET",font = font.big,
                  command = function() assign('task',1,envir = env))
  butt2 <- tcltk::tkbutton(win.main,width = 17,text="NEW DATA",font = font.big,
                  command = function() assign('task',2,envir = env))
  butt3 <- tcltk::tkbutton(win.main,width = 17,text="WORK ON DATA",font = font.big,
                  command = function() assign('task',3,envir = env))
  butt4 <- tcltk::tkbutton(win.main,width = 17,text="DELETE SM",font = font.big,
                  command = function() assign('task',4,envir = env))
  butt5 <- tcltk::tkbutton(win.main,width = 17,text="DELETE DATA",font = font.big,
                  command = function() assign('task',5,envir = env))
  butt6 <- tcltk::tkbutton(win.main,width = 14,text="SCALE",font = font.big,
                  command = function() assign('task',6,envir = env))
  # FILL STRUCTURES
  tcltk::tkgrid(labe1,padx = c(15,0),sticky="w",columnspan = 1,row = 1)
  tcltk::tkgrid(entry,row = 0,column = 0,padx = c(10,0))
  tcltk::tkgrid(butt1,row = 0,column = 1,padx = 15,pady = 8)
  tcltk::tkgrid(butt2,row = 1,column = 1,padx = 15,pady = 8)
  tcltk::tkgrid(butt3,row = 1,column = 3,padx = 15,pady = 8)
  tcltk::tkgrid(butt4,row = 3,column = 1,padx = 15,pady = c(5,8))
  tcltk::tkgrid(butt5,row = 3,column = 3,pady = c(5,8),padx=15)
  tcltk::tkgrid(butt6,column = 2,row = 3,pady = c(5,8),sticky = 'e')
  # VARIABLES FOR HANDLING DOUBLE LISTBOX
  is.gse.sel <- 0
    # 1 if matrix is selected, 0 otherwise
  is.mat.sel <- 0
    # 1 if data is selected, 0 otherwise
  
  ###################################################################
  
  # REFRESH FLAG
  refresh <- 1
  # PROGRAM MAIN LOOP - KEEP WORKING UNTIL WINDOW DOES EXIST
  while(as.integer(tcltk::tkwinfo('exists',win.main))){
    # REFRESH WHEN NEEDED, SPECIALIZED REFRESH 1,2
    if (refresh==1) {
      # UPDATE THE SELECTED SERIES MATRIX LABEL
      label.gse <- tcltk::tklabel(win.main,text='______________________________________',font = font.top,justify="left",padx = 10,foreground = mycolor)
      tcltk::tkgrid(label.gse,column = 2,row = 0,columnspan = 3,padx = 10)
      if(length(GSE)>0)
        label.gse <- tcltk::tklabel(win.main,text = paste('"',substr(GSE[1],1,30),'" sm',sep=''),font = font.top,justify="left",padx = 10)
      else
        label.gse <- tcltk::tklabel(win.main,text = paste('no sm available',sep=''),font = font.top,justify="left",padx = 10)
      tcltk::tkgrid(label.gse,column = 2,row = 0,columnspan = 3,padx = 10)
      # UPDATE SERIES MATRIX SCROLLBAR
      list.of.gse <- tcltk::tklistbox(win.main,height = 10,width = 62,selectmode="single")
      tcltk::tkgrid(list.of.gse,pady = 5,columnspan = 2,row = 2,padx = c(10,0))
      # FILL IT WITH VARIABLE NAMES GSE
      for(gse in GSE){
        Sys.sleep(0.01)
        tcltk::tkinsert(list.of.gse,"end",gse)
      }
    }
      
    # REFRESH IS 1 OR 2
    if (refresh>0) {
      label <- tcltk::tklabel(win.main,text='______________',font = font.top,foreground = mycolor)
      tcltk::tkgrid(label,row = 1,column = 2,sticky='e')
      # UPDATE LINKED DATA SCROLLBAR
      list.of.mat <- tcltk::tklistbox(win.main,height = 10,width = 62,selectmode="single")
      tcltk::tkgrid(list.of.mat,pady = 5,columnspan = 2,row = 2,column = 2,padx = 10)
      # FILL IT WITH VARIABLE NAMES GSE.MAT
      if(length(GSE)>0){
        # UPDATE SELECTION FLAGS
        if(length(MAT[[GSE[1]]])==0){
          is.mat.sel <- 0
          is.gse.sel <- 1
        }
        for(mat in MAT[[GSE[1]]]){
          Sys.sleep(0.01)
          tcltk::tkinsert(list.of.mat,"end",mat)
        }
      }
      else
        is.gse.sel <- 0
      if(is.mat.sel){
        data <- get(MAT[[GSE[1]]][1],envir=.GlobalEnv)
        d1 <- as.character(dim(data)[1])
        d2 <- as.character(dim(data)[2])
        label <- tcltk::tklabel(win.main,text = paste('dim:  ',d1,'x',d2,'  ',sep=''),font = font.top)
        tcltk::tkgrid(label,row = 1,column = 2,sticky='e')
      }
      # KEEP WHAT WAS SELECTED BEFORE
      # ...(UNLESS THERE ARE NO VARIABLES AVAILABLE)
      if(is.mat.sel==1)
        tcltk::tkselection.set(list.of.mat,0)
      if(is.gse.sel==1)
        tcltk::tkselection.set(list.of.gse,0)
      
      # FOCUS WINDOW
      tcltk::tkfocus(win.main)
      # REFRESH TASK ENDED
      refresh <- 0
    }
    
    #################################################################
  
    # DIFFERENT MATRIX/DATA SELECTED
    # ...TRY IS TO AVOID ERROR MESSAGES AFTER DESTROYING THE WINDOW
    gse.sel <- try(as.numeric(tcltk::tkcurselection(list.of.gse)),silent = TRUE)
    mat.sel <- try(as.numeric(tcltk::tkcurselection(list.of.mat)),silent = TRUE)

    # SELECTED MATRIX
    if(is.numeric(gse.sel)&length(gse.sel)>0){
      if(gse.sel>0){
        refresh <- 1
        # MOVE AT THE TOP WHEN SELECTED
        GSE.OLD <- GSE
        GSE[1]<-GSE[gse.sel+1]
        GSE[2:length(GSE)]<-GSE.OLD[-(gse.sel+1)]
      }
      # NO DATA ARE SELECTED ANYMORE
      is.gse.sel <- 1
      is.mat.sel <- 0
    }
    
    # SELECTED DATA
    if(is.numeric(mat.sel)&length(mat.sel)>0){
      if(mat.sel>0){
        refresh <- 2
        # MOVE AT THE TOP WHEN SELECTED
        MAT.OLD <- MAT[[GSE[1]]]
        MAT[[GSE[1]]][1]<-MAT[[GSE[1]]][mat.sel+1]
        MAT[[GSE[1]]][2:length(MAT.OLD)]<-MAT.OLD[-(mat.sel+1)]
      }
      if(is.mat.sel==0)
        refresh <- 2
      # NO GSE ARE SELECTED ANYMORE
      is.gse.sel <- 0
      is.mat.sel <- 1
    }
    
    #################################################################
    
    if(task==1){
      getGSE(env)
      refresh <- 1
      task <- 0
    }
    if(task==2){
      getData(env)
      refresh <- 2
      task <- 0
    }
    if(task==3){
      workonData(env)
      refresh <- 2
      task <- 0
    }
    if(task==4){
      deleteGSE(env)
      refresh <- 1
      task <- 0
    }
    if(task==5){
      deleteData(env)
      refresh <- 2
      task <- 0
    }
    if(task==6){
      scaleData(env)
      task <- 0
    }
  }
  
  ###################################################################
  
  # END OF FUNCTION - THANK YOU FOR THE ATTENTION
}


#' @title getGSE
#' @description Imports series matrices with the "LOAD DATASET" option in iGEO. If the name does not correspond to any dataset in GEO, an error message is launched, but the program keeps running! If a GSE file contains many series matrices, all of them are imported. You can rename each series matrix.
#' @arguments env0 the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads series matrices (class: ExpressionSet) to global environment, and checks if there are already some associated data.
#' @export
getGSE<-function(env0){
  
  ##########################################################
  
  # LOCAL TASK FLAG
  task<-0
  # LOCAL ENVIRONMENT
  env<-environment()
  # LOADING REQUIRED VARIABLES
  GLOB<-get('GLOB',envir=env0)
  MAT.RAW<-get('MAT.RAW',envir=env0)
  MAT<-get('MAT',envir=env0)
  GSE<-get('GSE',envir=env0)
  font.top<-get('font.top',envir=env0)
  # DATABASE ID
  id<-get('id',envir=env0)
  id<-as.character(tcltk::tclvalue(id))
  # LOAD FILE IF IT DOES EXIST
  gse<-try(GEOquery::getGEO(id,GSEMatrix=TRUE,getGPL=FALSE),silent=TRUE)
  # INSUCCESS
  if(class(gse)=="try-error"){
    tcltk::tkmessageBox(message=paste(id,'not available'),icon="error",type="ok")
    return()
  }
  else
    class(gse)<-'ExpressionSet'
  
  ##########################################################
  
  # SUCCESS - RENAME SERIES MATRICES
  # INITIALIZE WINDOW
  win.gse<-tcltk::tktoplevel()
  tcltk::tktitle(win.gse)<-'Rename series matrices'
  # SERIES MATRICES NAMES
  NAMES<-names(gse)
  if(is.null(NAMES))
    NAMES<-c(id)
  # RENAME SERIES MATRICES
  ENTRY.NAMES<-list()
  # CREATE ENTRIES FOR RENAMING
  for(i in 1:length(NAMES)){
    ENTRY.NAMES[[i]]<-tcltk::tclVar(init=NAMES[i])
    entry<-tcltk::tkentry(win.gse,textvariable=ENTRY.NAMES[[i]],width=40)
    tcltk::tkgrid(entry,padx=20,pady=12)
  }
  # EXECUTE BUTTON
  tcltk::tkgrid(tcltk::tkbutton(win.gse,width=12,text="EXECUTE",font=font.top,command=function() assign('task',1,envir=env)),padx=20,sticky='e',pady=c(0,10))
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.gse)))
    if(task>0){
      
      gse.name<-c()
      
      #############################################################################
      
      # RUN TASK - CREATE MATRIX
      for(i in 1:length(NAMES)){
        # LOAD MATRIX FROM GSE
        if(NAMES[i]==id)
          gse<-gse
        else
          gse<-get(NAMES[i],gse)
        # LOAD THE MATRIX VARIABLE NAME
        gse.name[i]<-as.character(tcltk::tclvalue(ENTRY.NAMES[[i]]))
        # CHECK IF YOU OVERWRITE SOMETHING
        if(sum(gse.name[i]==GLOB)){
          answer<-tcltk::tkmessageBox(message=paste("Do you want to overwrite ",gse.name[i],'?',sep=''),
                               icon = "warning", type = "yesno", default = "yes")
          answer<-as.character(tcltk::tclvalue(answer))
          if(answer=='no'){
            task<-0
            break
          }
        }
      }
      if(task>0)
        break
    }
  
  if(task==0)
    return()
  
  #############################################################################
  
  # CREATE
  for(i in 1:length(NAMES)){
    index<-which(GSE==gse.name[i])
    # WAS ALREADY THERE - PUT IN FIRST POSITION
    if(length(index)>0){
      GSE.OLD<-GSE
      GSE[1]<-GSE[index]
      if(length(GSE)>1)
        GSE[2:length(GSE)]<-GSE.OLD[-index]
    }
    else{
      # ADD gse.name TO LIST OF GSE VARIABLES, IN FIRST POSITION
      if(length(GSE)>0){
        GSE[length(GSE)+1]<-''
        GSE[2:length(GSE)]<-GSE[1:length(GSE)-1]
      }
      GSE[1]<-gse.name[i]
      GLOB<-c(GLOB,gse.name[i])
    }
    # CREATE THE VARIABLE
    assign(gse.name[i],gse,envir=.GlobalEnv)
    # FIND RELATED DATA
    GSE.COL<-colnames(gse)
    GSE.MAT<-c()
    for(mat in MAT.RAW){
      if(is.null(mat))
        next
      col<-colnames(get(mat,envir=.GlobalEnv))[1]
      if(!is.null(col))
        if(sum(GSE.COL==col))
          GSE.MAT<-c(GSE.MAT,mat)
    }
    MAT[[gse.name[i]]]<-GSE.MAT
  }
  
  #############################################################################
  
  # UPLOAD GSE TO HIGHER ENVIRONMENT
  assign('GLOB',GLOB,envir=env0)
  assign('MAT',MAT,envir=env0)
  assign('GSE',GSE,envir=env0)
  assign('is.mat.sel',0,envir=env0)
  assign('is.gse.sel',1,envir=env0)
  tcltk::tkdestroy(win.gse)
}


#' @title getData
#' @description Creates a new expression-data matrix associated to selected dataset with the "CREATE DATA" option. If no series matrix is either selected or available, an error message is launched, but the program keeps running!
#' @arguments env0 the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads the expression-data matrix (class: ExpressionSet) to global environment, and checks if there are some other associated series matrices.
#' @export
getData<-function(env0){
  
  ##########################################################
  
  # LOCAL TASK FLAG
  task<-0
  # LOCAL ENVIRONMENT
  env<-environment()
  # LOAD VARIABLES
  font.top<-get('font.top',envir=env0)
  GLOB<-get('GLOB',envir=env0)
  MAT<-get('MAT',envir=env0)
  GSE<-get('GSE',envir=env0)
  is.gse.sel<-get('is.gse.sel',envir=env0)
  is.mat.sel<-get('is.mat.sel',envir=env0)
  if(length(GSE)==0){
    tcltk::tkmessageBox(message='No GSE available!',icon="error",type="ok")
    return()
  }
  gse<-GSE[1]
  
  ##########################################################
  
  # INITIALIZE WINDOW
  win.getdata<-tcltk::tktoplevel()
  tcltk::tktitle(win.getdata)<-'Enter data name'
  # INITIALIZE ENTRY VARIABLE
  data.entry<-tcltk::tclVar(init=paste('data.',gse,sep=''))
  # INIZIALIZE OBJECTS
  labe1<-tcltk::tklabel(win.getdata,text=paste('"',gse,'" series matrix',sep=''),font=font.top,justify="left")
  entry<-tcltk::tkentry(win.getdata,width=40,textvariable=data.entry)
  butt1<-tcltk::tkbutton(win.getdata,width=17,text="EXECUTE",font=font.top,
                  command=function() assign('task',1,envir=env))
  # PUT OBJECTS INTO WINDOW
  tcltk::tkgrid(labe1,pady=10)
  tcltk::tkgrid(entry,padx=20,pady=12)
  tcltk::tkgrid(butt1,pady=c(0,10),padx=10,sticky='e')
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.getdata)))
    if(task>0){
      data.name<-as.character(tcltk::tclvalue(data.entry))
      # HANDLE OVERWRITING
      if(sum(data.name==GLOB)>0){
        answer<-tcltk::tkmessageBox(message=paste("Do you want to overwrite ",data.name,'?',sep=''),
                             icon = "warning", type = "yesno", default = "yes")
        answer<-as.character(tcltk::tclvalue(answer))
        if(answer=='yes'){
          data<-exprs(get(gse,envir=.GlobalEnv))
          col<-colnames(data)[1]
          for(gse in GSE){
            index<-which(MAT[[gse]]==data.name)
            # IT WASN'T THERE AND IT HAS TO BE ADDED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)==0){
              if(length(MAT[[gse]])>0){
                MAT[[gse]][length(MAT[[gse]])+1]<-''
                MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
              }
              MAT[[gse]][1]<-data.name
            }
            # IT WAS THERE AND IT HAS TO BE REMOVED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))==0&
               length(index)>0)
              MAT[[gse]]<-MAT[[gse]][-index]
            # IT WAS THERE AND IT HAS TO BE REFRESHED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)>0){
              MAT.OLD<-MAT[[gse]]
              MAT[[gse]][1]<-MAT[[gse]][index]
              if(length(MAT.OLD)>1)
                MAT[[gse]][2:length(MAT.OLD)]<-MAT.OLD[-index]
            }
          }
          task<-2
          tcltk::tkdestroy(win.getdata)
          break
        }
        task<-0
      }
      else
        break
    }
  
  # NO TASK
  if(task==0)
    return()
  
  ############################################################
  
  if(task==1){
    # CREATE EXPRESSION DATA IN GLOBAL ENVIRONMENT
    # CREATE EXPRESSION DATA VARIABLE
    data<-exprs(get(gse,envir=.GlobalEnv))
    col<-colnames(data)[1]
    for(gse in GSE){
      if(sum(col==colnames(get(gse,envir=.GlobalEnv)))){
        # UPDATE MAT and GSE
        if(length(MAT[[gse]])>0){
          MAT[[gse]][length(MAT[[gse]])+1]<-''
          MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
        }
        MAT[[gse]][1]<-data.name
        GLOB<-c(GLOB,data.name)
      }
    }
  }
  assign(data.name,data,envir=.GlobalEnv)
  # UPLOAD VAR TO HIGHER ENVIRONMENT
  assign('GLOB',GLOB,envir=env0)
  assign('MAT',MAT,envir=env0)
  assign('GSE',GSE,envir=env0)
  assign('is.gse.sel',0,envir=env0)
  assign('is.mat.sel',1,envir=env0)
  tcltk::tkdestroy(win.getdata)
}

#' @title deleteGSE
#' @description Deletes a series matrix with the "DELETE SM" option. It launches deleteGSE function. If no series matrix is either selected or available, an error message is launched, but the program keeps running!
#' @arguments env0 the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads global environment.
#' @export
deleteGSE<-function(env0){
  
  # LOAD REQUIRED VARIABLES FROM PARENT DIRECTORY
  is.gse.sel<-get('is.gse.sel',envir=env0)
  GLOB<-get('GLOB',envir=env0)
  GSE<-get('GSE',envir=env0)
  MAT<-get('MAT',envir=env0)
  
  ##########################################################
  
  # NO GSE SELECTED
  if(is.gse.sel==0){
    tcltk::tkmessageBox(message='No GSE selected!',icon="error",type="ok")
    return()
  }
  delete.name<-GSE[1]
  
  ##########################################################
  
  # CHECK IF YOU REALLY WANT TO DELETE THE SERIES MATRIX
  answer<-tcltk::tkmessageBox(message=paste("Do you want to delete ",delete.name,'?',sep=''),
                       icon = "warning", type = "yesno", default = "yes")
  answer<-as.character(tcltk::tclvalue(answer))
  if(answer=='no')
    return()
  
  ##########################################################
  
  # PROCEED - REMOVE THE SERIES MATRIX
  remove(list=c(delete.name),envir=.GlobalEnv)
  # REMOVE THE LINKS TO DATA RELATED TO THE MATRIX
  MAT[[GSE[1]]]<-NULL
  # REMOVE THE VARIABLE NAME FROM THE RELATED LIST
  GSE<-GSE[-1]
  GLOB<-GLOB[-which(GLOB==delete.name)]
  # UPLOAD GLOB.GSE TO HIGHER ENVIRONMENT
  assign('GSE',GSE,envir=env0)
  assign('MAT',MAT,envir=env0)
  assign('GLOB',GLOB,envir=env0)
}



#' @title getFactor
#' @description Adds a factor row to a expression-data matrix
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' \cr \cr
#' env.main the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Factor is added according to informations contained in pData(series.matrix). You can rename both factor and levels in factor, add multiple factors at once and merge factors with a factorial product ("MERGE" option).
#' You can't add a factor whose name is already present as a rowname in the data matrix. In this case, the program informs you with a warning message.
#' Eventually, it uploads data object to global environment.
#' @export
getFactor <- function(env0,env.main){
  
  # GRAPHICAL ISSUES
  font.top <- tcltk::tkfont.create(weight="bold",slant="italic")
  font.big <- tcltk::tkfont.create(weight="bold")
  
  # LOCAL TASK FLAG
  task <- 0
  # LOCAL ENVIRONMENT
  env <- environment()
  
  fac.name<-'factor'
  
  #########################################################
  
  # RETRIEVE EVERYTHING
  data <- get('data',env = env0)
  mat.name <- get('mat.name',env = env0)
  gse.name <- get('gse.name',env = env0)
  matrix <- get('matrix',env = env0)
  pdata <- pData(matrix)
  FAC <- get('FAC',env = env0)
  GEN <- get('GEN',env = env0)
  LEV <- get('LEV',env = env0)
  # RETRIEVE THE LIST OF NAMES OF FACTORS AVAILABLE
  NAME.FAC.GSE <- varLabels(matrix)[grep('characteristics',varLabels(matrix))]
  # PROCEED IF THERE ARE FACTORS AVAILABLE
  num.fac.gse <- length(NAME.FAC.GSE)
  if(num.fac.gse==0){
    # FACTORS NOT FOUND
    tcltk::tkmessageBox(message="Factors not found!",icon="warning",type="ok")
    return()
  }
  
  #######################################################################
  
  #COLUMNS OF SM KEEPED IN DATA
  keep <- c()
  col.gse <- colnames(matrix)
  col.mat <- colnames(data)
  for(i in 1:length(col.gse))
    if(sum(col.gse[i]==col.mat))
      keep <- c(keep,i)
  
  #############################################################################
  
  # DEFINE THE ALL LEVELS VECTOR
  LEV.GSE <- list()
  # INITIALIZE FACTORS MATRIX (ONE FACTOR FOR EACH ROW)
  FAC.GSE <- as.data.frame(matrix(nrow = num.fac.gse,ncol = dim(data)[2]))
  # FILL FAC.GSE & LEV.GSE & NUM.LEV.GSE LOOP
  for(i in 1:num.fac.gse){
    # SHRINK FACTOR TO THOSE SAMPLES KEPT IN DATA
    fac <- get(NAME.FAC.GSE[i],pdata)[keep]
    LEV.GSE[[i]]<-levels(fac)
    FAC.GSE[i,]<-fac
  }
  
  #########################################################
  
  # INITIALIZE WINDOW
  win.fac <- tcltk::tktoplevel()
  tcltk::tktitle(win.fac)<-'Add factors'
  # INIZIALIZE FIXED OBJECTS (LEGEND)
  tcltk::tkgrid(tcltk::tklabel(win.fac,text=' Rename factor ',font = font.top),column = 0,row = 0,pady = c(5,10))
  tcltk::tkgrid(tcltk::tklabel(win.fac,text=' Select ',font = font.top),column = 1,row = 0)
  tcltk::tkgrid(tcltk::tklabel(win.fac,text=' Rename levels ',font = font.top,width = 10),column = 2,row = 0,padx = 5)
  # INITIALIZE ENTRY VARIABLES LIST
  ENTRY.BUT <- list() # of buttons state
  ENTRY.FAC <- list() # of factors (re)name
  ENTRY.LEV <- list() # of levels (re)name (list of lists)
  
  #########################################################
  
  # LEVELS' PROGRESSIVE COUNTER
  n <- 1
  # FILL THE WINDOW FOR EACH FACTOR
  for(i in 1:num.fac.gse){
    l <- length(LEV.GSE[[i]])
    # INITIALIZE FACTOR OBJECTS & VARIABLES
    ENTRY.BUT[[i]]<-tcltk::tclVar(init='0')
    ENTRY.FAC[[i]]<-tcltk::tclVar(init = NAME.FAC.GSE[i])
    ENTRY.LEV[[i]]<-list()
    entry <- tcltk::tkentry(win.fac,width="25",textvariable = ENTRY.FAC[[i]])
    butt1 <- tcltk::tkcheckbutton(win.fac)
    tcltk::tkconfigure(butt1,variable = ENTRY.BUT[[i]])
    # PUT 'EM IN THE WINDOW
    tcltk::tkgrid(entry,column = 0,row = n+1,rowspan = l,padx = 10,pady = 6,sticky='n')
    tcltk::tkgrid(butt1,column = 1,row = n+1,rowspan = l,padx = 10,pady = 4,sticky='n')
    # LEVELS LOOP (FOR EACH FACTOR)
    for(j in 1:l){
      ENTRY.LEV[[i]][[j]]<-tcltk::tclVar(init = LEV.GSE[[i]][j])
      laben <- tcltk::tklabel(win.fac,text = paste(sum(FAC.GSE[i,]==LEV.GSE[[i]][j]),'sample(s)'))
      entry <- tcltk::tkentry(win.fac,width="40",textvariable = ENTRY.LEV[[i]][[j]])
      pady = 0
      if(j==1)
        pady = c(6,0)
      if(j==l)
        pady = c(0,6)
      tcltk::tkgrid(entry,row = n+j,column = 2,padx = 10,pady = pady)
      tcltk::tkgrid(laben,row = n+j,column = 3,padx = 10,pady = pady)
    }
    # UPDATE LEVELS' PROGRESSIVE COUNTER
    n <- n+l
  }
  tcltk::tkgrid(tcltk::tklabel(win.fac,text=' '),column = 0,columnspan = 5)
  # MERGE OPTION
  pack <- tcltk::tclVar(init='0')
  butt <- tcltk::tkcheckbutton(win.fac)
  tcltk::tkconfigure(butt,variable = pack)
  tcltk::tkgrid(tcltk::tklabel(win.fac,text='merge selected factors',font = font.top),row = n+1,columnspan = 2,column = 0,sticky='e')
  tcltk::tkgrid(butt,column = 2,row = n+1)
  # EXECUTE BUTTON
  tcltk::tkgrid(tcltk::tkbutton(win.fac,width = 12,text="EXECUTE",font = font.big,
                  command = function() assign('task',1,envir = env)),row = n+1,column = 3,pady = 5,padx = 10)
  # FOCUS WINDOW
  tcltk::tkfocus(win.fac)
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.fac)))
    if(task>0){
      # VECTOR OF SELECTED FACTORS
      FAC.SEL <- c()
      # SCAN FACTORS AND LEVELS TO GET INFO
      for(i in 1:num.fac.gse){
        # IF THE CHARACTERISTIC HAS BEEN SELECTED
        if(as.character(tcltk::tclvalue(ENTRY.BUT[[i]]))=='1'){
          # SUMMARIZE THE INFORMATION IN VECTOR FAC.SEL
          FAC.SEL <- c(FAC.SEL,i)
          # RECOVER FACTOR
          fac <- as.factor(as.vector(as.matrix(FAC.GSE[i,])))
          l <- length(LEV.GSE[[i]])
          # OVERWRITE LEVEL NAMES
          for(j in 1:l)
            LEV.GSE[[i]][j]<-as.character(tcltk::tclvalue(ENTRY.LEV[[i]][[j]]))
          # CHANGE THE SPECIFIC LEVELS (MUST BE ALL TOGETHER!!)
          levels(fac)<-LEV.GSE[[i]]
          # UPDATE FAC
          FAC.GSE[i,]<-fac
          # NEW NAME TO ASSIGN TO FACTOR
          NAME.FAC.GSE[i]<-as.character(tcltk::tclvalue(ENTRY.FAC[[i]]))
        }
      }
      
      # CHECK NAME REPEATS IN CASE OF NO-PACKING OPTION
      redo<-0  
      pack <- as.character(tcltk::tclvalue(pack))
      if(pack=='0'){
        for(fac.sel in FAC.SEL){
          fac <- FAC.GSE[fac.sel,]
          colnames(fac)<-colnames(data)
          fac.name <- NAME.FAC.GSE[fac.sel]
          rownames(fac)<-fac.name
          data <- rbind.data.frame(data,fac)
          if(sum(fac.name==c(FAC,GEN))){
            tcltk::tkmessageBox(message = paste("Factor",fac.name,"is already present! Please type another name"),icon="error",type="ok")
            redo<-1
            break
          }
        }
        # DOESN'T GO ON WITHOUT PROPER FACTOR NAMES!
        if(redo==1){
          task<-0
          next
        }
      }
      break
    }
  
  if(task==0)
    return()
  
  # HANDLE NO FACTOR SELECTION
  if(length(FAC.SEL)==0){
    tcltk::tkdestroy(win.fac)
    return()
  }
  
  #######################################################
  
  # HANDLE MERGE OPTION
  if(pack=='1'){
    task <- 0
    # CHOOSE MERGED FACTOR NAME
    win.fac2 <- tcltk::tktoplevel()
    tcltk::tktitle(win.fac2)<-'Choose factor name'
    butt <- tcltk::tkbutton(win.fac2,width = 12,text="EXECUTE",font = font.top,
                     command = function() assign('task',1,envir = env))
    fac.name <- tcltk::tclVar(init = fac.name)
    entry <- tcltk::tkentry(win.fac2,width="35",textvariable = fac.name)
    tcltk::tkgrid(entry,padx = 40,pady = c(10,0))
    tcltk::tkgrid(butt,pady = 10)
    tcltk::tkfocus(win.fac2)
    # WAIT UNTIL INTERACTION WITH OK BUTTON
    while(as.integer(tcltk::tkwinfo('exists',win.fac2)))
      if(task>0){
        fac.name <- as.character(tcltk::tclvalue(fac.name))
        fac <- c()
        for(i in FAC.SEL)
          fac <- paste(fac,FAC.GSE[i,])
        fac <- matrix(fac,ncol = ncol(data))
        colnames(fac)<-colnames(data)
        rownames(fac)<-fac.name
        if(length(FAC)>0){
          FAC[1+length(FAC)]<-''
          FAC[1:length(FAC)]<-FAC[1:(length(FAC)-1)]
        }
        data <- rbind.data.frame(data,fac)
        # handle renames
        if(sum(fac.name==c(FAC,GEN))){
          tcltk::tkmessageBox(message = paste("Factor",fac.name,"is already present! Please type another name"),icon="error",type="ok")
          next
        }
        FAC[1]<-fac.name
        LEV[[fac.name]]<-levels(as.factor(fac))
        tcltk::tkdestroy(win.fac2)
        break
      }
  }
  
  if(pack=='0')
    for(fac.sel in FAC.SEL){
      if(length(FAC)>0){
        FAC[1+length(FAC)]<-''
        FAC[1:length(FAC)]<-FAC[1:(length(FAC)-1)]
      }
      FAC[1]<-fac.name
      LEV[[fac.name]]<-intersect(LEV.GSE[[fac.sel]],LEV.GSE[[fac.sel]])
    }
    
  # DESTROY THE WINDOW
  tcltk::tkdestroy(win.fac)
  
  assign(mat.name,data,envir=.GlobalEnv)
  # FINALLY TO HIGHER ENVIRONMENT
  assign('FAC',FAC,envir = env0)
  assign('LEV',LEV,envir = env0)
}

#' @title renameLevel
#' @description Renames a factor and its levels.
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' \cr \cr
#' env.main the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads data object to global environment.
#' @export
renameLevel<-function(env0){
  
  task<-0
  env<-environment()
  font.top<-tcltk::tkfont.create(weight="bold",slant="italic")
  
  
  FAC<-get('FAC',envir=env0)
  if(length(FAC)==0){
    tcltk::tkmessageBox(message='No factor available!',icon="error",type="ok")
    return()
  }
  LEV<-get('LEV',envir=env0)
  data<-get('data',envir=env0)
  mat.name<-get('mat.name',envir=env0)
  LEV.FAC<-LEV[[FAC[1]]]
  lev.index<-list()
  
  win.lev<-tcltk::tktoplevel()
  tcltk::tktitle(win.lev)<-'Rename/merge levels'
  # RENAME SERIES MATRICES
  ENTRY.LEV<-list()
  # CREATE ENTRIES FOR RENAMING
  for(i in 1:length(LEV.FAC)){
    ENTRY.LEV[[i]]<-tcltk::tclVar(init=LEV.FAC[i])
    entry<-tcltk::tkentry(win.lev,textvariable=ENTRY.LEV[[i]],width=40)
    tcltk::tkgrid(entry,padx=20,pady=6,column=1,row=i)
    laben<-tcltk::tklabel(win.lev,text=paste(sum(LEV.FAC[i]==data[FAC[1],]),'sample(s)'))
    lev.index[[i]]<-which(LEV.FAC[i]==data[FAC[1],])
    tcltk::tkgrid(laben,padx=c(0,20),column=2,row=i)
  }
  # OCCASIONALLY, RENAME FACTOR NAME
  label<-tcltk::tklabel(win.lev,text='Factor name',font=font.top)
  tcltk::tkgrid(label,padx=c(0,20),column=1,columnspan=2,row=i+1)
  i<-i+1
  ENTRY.LEV[[i]]<-tcltk::tclVar(init=FAC[1])
  entry<-tcltk::tkentry(win.lev,textvariable=ENTRY.LEV[[i]],width=60)
  tcltk::tkgrid(entry,padx=20,pady=6,column=1,columnspan=2,row=i+1)
  # EXECUTE BUTTON
  tcltk::tkgrid(tcltk::tkbutton(win.lev,width=12,text="EXECUTE",font=font.top,command=function() assign('task',1,envir=env)),padx=20,sticky='e',pady=c(0,10),row=i+2,columnspan=2,column=0)
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.lev)))
    if(task>0){
      # RUN TASK - CHANGE LEVELS
      # the same i as before!
      new.fac<-as.character(tcltk::tclvalue(ENTRY.LEV[[i]]))
      for(i in 1:length(LEV.FAC)){
        # LOAD THE LEVEL NAME
        LEV.FAC[i]<-as.character(tcltk::tclvalue(ENTRY.LEV[[i]]))
        row.index<-which(rownames(data)==FAC[1])
        rownames(data)[row.index]<-new.fac
        data[new.fac,lev.index[[i]]]<-LEV.FAC[i]
      }
      LEV.FAC<-intersect(LEV.FAC,LEV.FAC)
      break
    }
  
  if(task==0)
    return()
  
  tcltk::tkdestroy(win.lev)
  
  #############################################################################
  
  LEV[[FAC[1]]]<-NULL
  LEV[[new.fac]]<-LEV.FAC
  FAC[1]<-new.fac
  assign(mat.name,data,envir=env0)
  assign('data',data,envir=env0)
  assign('LEV',LEV,envir=env0)
  assign('FAC',FAC,envir=env0)
  assign(mat.name,data,envir=.GlobalEnv)
}

#' @title deleteFactor
#' @description Deletes a factor and its levels.
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads data object to global environment.
#' @export
deleteFactor<-function(env0){
  
  # LOAD REQUIRED VARIABLES FROM PARENT DIRECTORY
  is.fac.sel<-get('is.fac.sel',envir=env0)
  data<-get('data',envir=env0)
  mat.name<-get('mat.name',envir=env0)
  FAC<-get('FAC',envir=env0)
  LEV<-get('LEV',envir=env0)
  
  ##########################################################
  
  # NO SERIES MATRIX SELECTED
  if(is.fac.sel==0){
    tcltk::tkmessageBox(message='No factors selected!',icon="error",type="ok")
    return()
  }
  delete.name<-FAC[1]
  
  ##########################################################
  
  # CHECK IF YOU REALLY WANT TO DELETE THE FACTOR
  answer<-tcltk::tkmessageBox(message=paste("Do you want to delete ",delete.name,'?',sep=''),
                       icon = "warning", type = "yesno", default = "yes")
  answer<-as.character(tcltk::tclvalue(answer))
  if(answer=='no')
    return()
  
  ##########################################################
  
  # PROCEED - REMOVE THE SERIES MATRIX
  index<-which(rownames(data)==FAC[1])
  data<-data[-index,]
  # REMOVE THE LINKS TO LEVELS RELATED TO THE MATRIX
  LEV[[FAC[1]]]<-NULL
  # REMOVE THE VARIABLE NAME FROM THE RELATED LIST
  FAC<-FAC[-1]
  # UPLOAD TO HIGHER ENVIRONMENT
  assign('FAC',FAC,envir=env0)
  assign('LEV',LEV,envir=env0)
  assign('data',data,envir=env0)
  assign(mat.name,data,envir=.GlobalEnv)
}


#' @title searchGENE
#' @description Searches a probe ID among the rownames of the dataset.
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, if the gene is found, it puts it at the top of the related panel.
#' @export
searchGENE<-function(env0){
  
  GEN<-get('GEN',envir=env0)
  gene<-as.character(tcltk::tclvalue(get('gene',envir=env0)))
  index<-which(GEN==gene)
  if(length(index)==0){
    
    # GENE NOT FOUND
    tcltk::tkmessageBox(message="Gene not found!",icon="warning",type="ok")
  }
  else{
    GEN.OLD<-GEN
    GEN[1]<-GEN[index]
    GEN[2:length(GEN)]<-GEN.OLD[-index]
    assign('GEN',GEN,envir=env0)
    assign('is.gen.sel',1,envir=env0)
    assign('is.sam.sel',0,envir=env0)
    assign('is.fac.sel',0,envir=env0)
    assign('is.lev.sel',0,envir=env0)
    assign('refresh',2,envir=env0)
  }
  
}


#' @title sampleSelect
#' @description Reduces the number of probes by retaining just those with a selected level of a factor.
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' \cr \cr
#' env.main the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads data object to global environment.
#' @export
sampleSelect<-function(env0,env.main){
  
  ##########################################################
  
  # LOCAL TASK FLAG
  task<-0
  # LOCAL ENVIRONMENT
  env<-environment()
  # LOAD VARIABLES
  font.top<-get('font.top',envir=env0)
  MAT<-get('MAT',envir=env.main)
  GSE<-get('GSE',envir=env.main)
  GLOB<-get('GLOB',envir=env.main)
  SAM<-get('SAM',envir=env0)
  SAM.SEL<-get('SAM.SEL',envir=env0)
  if(length(SAM)==length(SAM.SEL)){
    tcltk::tkmessageBox(message='Subset coincides with the whole data!',icon="error",type="ok")
    return()
  }
  LEV<-get('LEV',envir=env0)
  FAC<-get('FAC',envir=env0)
  data<-get('data',envir=env0)
  mat.name<-get('mat.name',envir=env0)
  gse<-GSE[1]
  
  ##########################################################
  
  # INITIALIZE WINDOW
  win.saveas<-tcltk::tktoplevel()
  tcltk::tktitle(win.saveas)<-'Save selected data as'
  # INITIALIZE ENTRY VARIABLE
  data.entry<-tcltk::tclVar(init=mat.name)
  # INIZIALIZE OBJECTS
  entry<-tcltk::tkentry(win.saveas,width=40,textvariable=data.entry)
  butt1<-tcltk::tkbutton(win.saveas,width=17,text="EXECUTE",font=font.top,
                  command=function() assign('task',1,envir=env))
  # PUT OBJECTS INTO WINDOW
  tcltk::tkgrid(entry,padx=20,pady=12)
  tcltk::tkgrid(butt1,pady=c(0,10),padx=10,sticky='e')
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.saveas)))
    if(task>0){
      data.name<-as.character(tcltk::tclvalue(data.entry))
      # HANDLE OVERWRITING
      if(sum(data.name==GLOB)>0){
        answer<-'yes'
        if(data.name!=mat.name){
          answer<-tcltk::tkmessageBox(message=paste("Do you want to overwrite ",data.name,'?',sep=''),
                               icon = "warning", type = "yesno", default = "yes")
          answer<-as.character(tcltk::tclvalue(answer))
        }
        if(answer=='yes'){
          data<-data[,SAM.SEL]
          col<-colnames(data)[1]
          for(gse in GSE){
            index<-which(MAT[[gse]]==data.name)
            # IT WASN'T THERE AND IT HAS TO BE ADDED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)==0){
              if(length(MAT[[gse]])>0){
                MAT[[gse]][length(MAT[[gse]])+1]<-''
                MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
              }
              MAT[[gse]][1]<-data.name
            }
            # IT WAS THERE AND IT HAS TO BE REMOVED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))==0&
               length(index)>0)
              MAT[[gse]]<-MAT[[gse]][-index]
            # IT WAS THERE AND IT HAS TO BE REFRESHED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)>0){
              MAT.OLD<-MAT[[gse]]
              MAT[[gse]][1]<-MAT[[gse]][index]
              if(length(MAT.OLD)>1)
                MAT[[gse]][2:length(MAT.OLD)]<-MAT.OLD[-index]
            }
          }
          task<-2
          break
        }
        task<-0
      }
      else
        break
    }
  
  # NO TASK
  if(task==0)
    return()
  
  ############################################################
  
  if(task==1){
    # CREATE EXPRESSION DATA IN GLOBAL ENVIRONMENT
    # CREATE EXPRESSION DATA VARIABLE
    data<-data[,SAM.SEL]
    col<-colnames(data)[1]
    
    for(gse in GSE){
      if(sum(col==colnames(get(gse,envir=.GlobalEnv)))){
        # UPDATE MAT and GSE
        if(length(MAT[[gse]])>0){
          MAT[[gse]][length(MAT[[gse]])+1]<-''
          MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
        }
        MAT[[gse]][1]<-data.name
        GLOB<-c(GLOB,data.name)
      }
    }
  }
  
  LEV[[FAC[1]]]<-LEV[[FAC[1]]][1]
  
  assign(data.name,data,envir=.GlobalEnv)
  # UPLOAD VAR TO HIGHER ENVIRONMENT
  assign('GLOB',GLOB,envir=env.main)
  assign('MAT',MAT,envir=env.main)
  assign('GSE',GSE,envir=env.main)
  assign('SAM',SAM.SEL,envir=env0)
  assign('FAC',FAC,envir=env0)
  assign('LEV',LEV,envir=env0)
  assign('mat.name',data.name,envir=env0)
  assign('data',data,envir=env0)
  tcltk::tkdestroy(win.saveas)
  
}


#' @title geneSelect
#' @description Reduces the number of probes by performing a ttest/ANOVA covariance test based on a factor.
#' @arguments env0 the environment created for the workonData function, such that required data are downloaded/uploaded directly from/to this environment.
#' \cr \cr
#' env.main the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Eventually, it uploads data object to global environment.
#' @export
geneSelect<-function(env0,env.main){
  
  ##########################################################
  
  # remove it, it is too costly
  p.adjust.methods<-p.adjust.methods[-which(p.adjust.methods=='hommel')]
  # LOCAL TASK FLAG
  task<-1
  # LOCAL ENVIRONMENT
  env<-environment()
  # LOAD VARIABLES
  
  MAT<-get('MAT',envir=env.main)
  GSE<-get('GSE',envir=env.main)
  GLOB<-get('GLOB',envir=env.main)
  GEN<-get('GEN',envir=env0)
  LEV<-get('LEV',envir=env0)
  FAC<-get('FAC',envir=env0)
  LEV.FAC<-LEV[[FAC[1]]]
  if(length(LEV.FAC)==0){
    # no levels to make differences!
    tcltk::tkmessageBox(message='No levels available!',icon="error",type="ok")
    return()
  }
  if(length(LEV.FAC)==1){
    # just one level to make differences!
    tcltk::tkmessageBox(message='Just one level available!',icon="error",type="ok")
    return()
  }
  font.top<-get('font.top',envir=env0)
  font.big<-get('font.big',envir=env0)
  data<-get('data',envir=env0)
  mat.name<-get('mat.name',envir=env0)
  gse<-GSE[1]
  
  #############################################################################
  
  # MODIFY DATA
  # RETRIEVE FACTOR
  fac<-c()
  for(i in 1:length(data[FAC[1],]))
    fac[i]<-data[FAC[1],i]
  fac<-as.factor(fac)
  # PERFORM PAIRWISE COLFTEST, TTEST IF THERE ARE JUST 2 LEVELS
  win.test<-tcltk::tktoplevel()
  if(length(LEV.FAC)==2){
    tcltk::tktitle(win.test)<-paste('T-test on',FAC[1])
    tt<-genefilter::rowttests(data.matrix(data[GEN,]),fac)
  }
  else{
    tcltk::tktitle(win.test)<-paste('F-test on',FAC[1])
    tt<-genefilter::rowFtests(data.matrix(data[GEN,]),fac)
  }
  
  #############################################################################
  
  # SELECT WHICH METHOD TO ADOPT & THRESHOLD
  # GRAPHICAL ISSUES
  thr<-tcltk::tclVar(init='0.05')
  data.entry<-tcltk::tclVar(init=mat.name)
  entry.methods<-tcltk::tclVar(p.adjust.methods[1])
  butt1<-tcltk::tkbutton(win.test,width=17,text='SET THRESH',font=font.big,
                  command=function() assign('task',1,envir=env))
  butt2<-tcltk::tkbutton(win.test,width=17,text='SAVE AS',font=font.big,
                  command=function() assign('task',2,envir=env))
  entry.thr<-tcltk::tkentry(win.test,width='12',textvariable=thr)
  entry.nam<-tcltk::tkentry(win.test,width='25',textvariable=data.entry)
  tcltk::tkgrid(entry.thr,column=2,row=0,padx=10,pady=5,sticky='w')
  tcltk::tkgrid(entry.nam,column=2,row=length(p.adjust.methods)+1,padx=10,pady=5)
  tcltk::tkgrid(butt1,column=0,columnspan=2,row=0,padx=10,pady=5)
  tcltk::tkgrid(butt2,column=0,columnspan=2,row=length(p.adjust.methods)+1,padx=10,pady=5)
  for(i in 1:length(p.adjust.methods)){
    labe<-tcltk::tklabel(win.test,text=p.adjust.methods[i])
    butt<-tcltk::tkradiobutton(win.test)
    tcltk::tkconfigure(butt,variable=entry.methods,value=p.adjust.methods[i])
    tcltk::tkgrid(labe,column=0,row=i,padx=10,sticky='e')
    tcltk::tkgrid(butt,column=1,row=i,padx=10)
  }
  # PROBABILITIES LIST
  p<-list()
  keep<-c()
  
  ##########################################################
  
  # WAIT FOR ACTIONS
  # ...EITHER WINDOW DESTROYED 
  # ...OR BUTTON PRESSED
  while(as.integer(tcltk::tkwinfo('exists',win.test))){
    
    if(task==1){
      for(i in 1:length(p.adjust.methods)){
        labe<-tcltk::tklabel(win.test,text='________________',fg='SystemMenu')
        tcltk::tkgrid(labe,column=2,row=i,padx=10,sticky='w')
      }
      for(i in 1:length(p.adjust.methods)){
        p[[i]]<-p.adjust(tt$p.value,method=p.adjust.methods[i])
        keep[i]<-sum(p[[i]]<as.numeric(tcltk::tclvalue(thr)))
        labe<-tcltk::tklabel(win.test,text=paste(keep[i],'gene(s)'))
        tcltk::tkgrid(labe,column=2,row=i,padx=10,sticky='w')
      }
      task<-0
    }
    
    if(task>1){
      data.name<-as.character(tcltk::tclvalue(data.entry))
      # HANDLE OVERWRITING
      if(sum(data.name==GLOB)>0){
        answer<-'yes'
        if(data.name!=mat.name){
          answer<-tcltk::tkmessageBox(message=paste("Do you want to overwrite ",data.name,'?',sep=''),
                               icon = "warning", type = "yesno", default = "yes")
          answer<-as.character(tcltk::tclvalue(answer))
        }
        if(answer=='yes'){
          # KEEP FACTORS!
          i<-which(p.adjust.methods==as.character(tcltk::tclvalue(entry.methods)))
          ord<-order(p[[i]])
          # GENES ARE NOW ORDERED FROM THE MOST RELEVANT TO THE LEAST
          if(length(keep[i])==0){
            tcltk::tkmessageBox(message='No genes available!',icon = "warning", type = "ok")
            return()
          }
          data<-rbind(data[ord[1:keep[i]],],data[FAC,])
          col<-colnames(data)[1]
          for(gse in GSE){
            index<-which(MAT[[gse]]==data.name)
            # IT WASN'T THERE AND IT HAS TO BE ADDED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)==0){
              if(length(MAT[[gse]])>0){
                MAT[[gse]][length(MAT[[gse]])+1]<-''
                MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
              }
              MAT[[gse]][1]<-data.name
            }
            # IT WAS THERE AND IT HAS TO BE REMOVED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))==0&
               length(index)>0)
              MAT[[gse]]<-MAT[[gse]][-index]
            # IT WAS THERE AND IT HAS TO BE REFRESHED
            if(sum(col==colnames(get(gse,envir=.GlobalEnv)))>0&
               length(index)>0){
              MAT.OLD<-MAT[[gse]]
              MAT[[gse]][1]<-MAT[[gse]][index]
              if(length(MAT.OLD)>1)
                MAT[[gse]][2:length(MAT.OLD)]<-MAT.OLD[-index]
            }
          }
          # BREAK WITH TASK=3: OVERWRITE MAT
          task<-3
          break
        }
        # OPERATION CANCELLED, KEEP IN LOOP WITH TASK=0
        task<-0
      }
      else
        # BREAK WITH TASK=2: CREATE MAT
        break
    }
  }
  
  # NO TASK
  if(task==0)
    return()
  
  
  ############################################################
  
  if(task==2){
    # CREATE EXPRESSION DATA IN GLOBAL ENVIRONMENT
    # CREATE EXPRESSION DATA VARIABLE
    # KEEP FACTORS!
    i<-which(p.adjust.methods==as.character(tcltk::tclvalue(entry.methods)))
    ord<-order(p[[i]])
    # GENES ARE NOW ORDERED FROM THE MOST RELEVANT TO THE LEAST
    if(length(keep[i])==0){
      tcltk::tkmessageBox(message='No genes available',icon = "warning", type = "ok")
      return()
    }
    data<-rbind(data[ord[1:keep[i]],],data[FAC,])
    col<-colnames(data)[1]
    for(gse in GSE){
      if(sum(col==colnames(get(gse,envir=.GlobalEnv)))){
        # UPDATE MAT and GSE
        if(length(MAT[[gse]])>0){
          MAT[[gse]][length(MAT[[gse]])+1]<-''
          MAT[[gse]][2:length(MAT[[gse]])]<-MAT[[gse]][1:(length(MAT[[gse]])-1)]
        }
        MAT[[gse]][1]<-data.name
        GLOB<-c(GLOB,data.name)
      }
    }
  }
  
  assign(data.name,data,envir=.GlobalEnv)
  # KEEP GENES
  GEN<-GEN[ord[1:keep[i]]]
  # UPLOAD VAR TO HIGHER ENVIRONMENT
  assign('GLOB',GLOB,envir=env.main)
  assign('MAT',MAT,envir=env.main)
  assign('GSE',GSE,envir=env.main)
  assign('GEN',GEN,envir=env0)
  assign('mat.name',data.name,envir=env0)
  assign('data',data,envir=env0)
  tcltk::tkdestroy(win.test)
  cat('\nList of selected genes:\n')
  for(j in 1:keep[i])
    cat(GEN[j],'\n')
}


#' @title workonData
#' @description Performs basic preliminary operations on data.
#' @arguments env0 the environment created for the main iGEO function, such that required data are downloaded/uploaded directly from/to this environment.
#' @details Data columns (samples), numeric rows (probes), text rows (factors and levels) are visualized in four different panels. You can perform different operations related to each panel.
#' \cr \cr
#' "SAMPLE SELECT" command calls sampleSelect function.
#' \cr \cr
#' "PROBE SELECT" command calls geneSelect function.
#' \cr \cr
#' "ADD FACTOR" command calls getFactor function.
#' \cr \cr
#' "RENAME LEVEL" command calls renameLevel function.
#' \cr \cr
#' "DELETE FACTOR" command calls deleteFactor function.
#' \cr \cr
#' Eventually, it uploads data object to global environment.
#' @export
workonData <- function(env0){
  
  env <- environment()
  task <- 0
  # LOAD REQUIRED VARIABLES: DATA & SERIES MATRIX
  is.mat.sel <- get('is.mat.sel',envir=env0)
  if(is.mat.sel==0){
    tcltk::tkmessageBox(message='No data selected!',icon="error",type="ok")
    return()
  }
  
  MAT <- get('MAT',envir=env0)
  GSE <- get('GSE',envir=env0)
  
  
  if(length(MAT[[GSE[1]]])==0){
    tcltk::tkmessageBox(message='No data associated with series matrix!',icon="error",type="ok")
    return()
  }
  
  mat.name <- MAT[[GSE[1]]][1]
  gse.name <- GSE[1]
  
  data <- get(mat.name,envir=.GlobalEnv)
  matrix <- get(gse.name,envir=.GlobalEnv)
  
  SAM <- intersect(colnames(data),colnames(matrix))
  l <- as.character(length(SAM))
  t <- l
  # in future: selected samples to be shown
  SAM.SEL <- SAM
  GEN <- intersect(rownames(data),rownames(matrix))
  FAC <- setdiff(rownames(data),rownames(matrix))
  # FIND LEVES RELATED TO FIRST FACTOR
  LEV <- list()
  
  for(fac in FAC)
    LEV[[fac]]<-levels(as.factor(as.matrix(data[fac,])))
  
  # BUILD WINDOW
  win.work <- tcltk::tktoplevel()
  tcltk::tktitle(win.work)<-paste('Work on',mat.name)
  # GRAPHICAL ISSUES
  font.top <- tcltk::tkfont.create(weight="bold",slant="italic")
  font.big <- tcltk::tkfont.create(weight="bold")
  # INITIALIZE STRUCTURES YOU DON'T HAVE TO UPLOAD PERIODICALLY
  labe.fill <- tcltk::tklabel(win.work,text='      ',font=font.top,justify="left",width=10)
  labe1 <- tcltk::tklabel(win.work,text="sample(s)",font=font.top,justify="left")
  labe2 <- tcltk::tklabel(win.work,text='gene(s)',font=font.top,justify="left")  
  labe3 <- tcltk::tklabel(win.work,text='factor(s)',font=font.top,justify='left')
  labe4 <- tcltk::tklabel(win.work,text='level(s)',font=font.top,justify='left')
  butt1 <- tcltk::tkbutton(win.work,width=17,text="TAKE SUBSET",font=font.big,
                    command=function() assign('task',1,envir=env))
  butt2 <- tcltk::tkbutton(win.work,width=17,text="TAKE SUBSET",font=font.big,
                    command=function() assign('task',2,envir=env))
  butt3 <- tcltk::tkbutton(win.work,width=17,text="ADD FACTOR",font=font.big,
                    command=function() assign('task',3,envir=env))
  butt4 <- tcltk::tkbutton(win.work,width=17,text="RENAME/MERGE",font=font.big,
                    command=function() assign('task',4,envir=env))
  butt5 <- tcltk::tkbutton(win.work,width=17,text="SEARCH GENE",font=font.big,
                    command=function() assign('task',5,envir=env))
  butt6 <- tcltk::tkbutton(win.work,width=17,text="DELETE FACTOR",font=font.big,
                    command=function() assign('task',6,envir=env))
  gene <- tcltk::tclVar(init='')
  entry <- tcltk::tkentry(win.work,width='25',textvariable=gene)
  # FILL STRUCTURES
  tcltk::tkgrid(labe1,sticky="w",column=1,row=0,pady=c(15,5))
  tcltk::tkgrid(labe2,padx=10,sticky="w",column=4,row=0,pady=c(15,5))
  tcltk::tkgrid(labe3,sticky="w",column=1,row=3,pady=c(15,5))
  tcltk::tkgrid(labe4,padx=10,sticky="w",column=4,row=3,pady=c(15,5))
  tcltk::tkgrid(butt1,row=0,column=2,padx=10,pady=c(15,5),sticky='e')
  tcltk::tkgrid(butt2,row=0,column=5,padx=10,pady=c(15,5),sticky='e')
  tcltk::tkgrid(butt3,row=3,column=2,padx=10,pady=c(15,5),sticky='e')
  tcltk::tkgrid(butt4,row=3,column=5,padx=10,pady=c(15,5),sticky='e')
  tcltk::tkgrid(butt5,row=2,column=5,padx=10,pady=c(10,10),sticky='n')
  tcltk::tkgrid(butt6,row=5,column=2,padx=10,pady=c(0,10),sticky='n')
  tcltk::tkgrid(entry,row=2,column=3,columnspan=2,pady=c(8,4))
  # VARIABLES FOR HANDLING QUADRUPLE LISTBOX
  is.fac.sel <- 0
  # 1 if matrix is selected, 0 otherwise
  is.lev.sel <- 0
  is.sam.sel <- 0
  is.gen.sel <- 0
  
  # REFRESH FLAG
  refresh <- c(1,2,3,4) # MEANS 'ALL'
  # PROGRAM MAIN LOOP - KEEP WORKING UNTIL WINDOW DOES EXIST
  while(as.integer(tcltk::tkwinfo('exists',win.work))){
    # REFRESH WHEN NEEDED - PARTICULAR REFRESH 1,2,3,4
    if(sum(refresh==1)){
      Sys.sleep(0.01)
      if(length(SAM)==0)
        is.sam.sel <- 0
      # SHOW JUST THOSE SAMPLES LINKED TO LEVEL
      if(is.lev.sel){
        SAM.SEL <- SAM[which(data[FAC[1],]==LEV[[FAC[1]]][1])]
        t <- paste(length(SAM.SEL),l,sep='/')
      }
      else
        t <- as.character(l)
      tcltk::tkgrid(labe.fill,row=0,column=0,pady=c(15,5))
      labe1c <- tcltk::tklabel(win.work,text=t,font=font.top,justify="left",width=10)
      tcltk::tkgrid(labe1c,row=0,column=0,pady=c(15,5))
      # UPDATE SAMPLES SCROLLBAR
      list.of.sam <- tcltk::tklistbox(win.work,height=10,width=62,selectmode="single")
      tcltk::tkgrid(list.of.sam,columnspan=3,row=1,rowspan=2,column=0,pady=c(0,10),padx=5)
      # FILL IT WITH VARIABLE NAMES IN SAM
      for(sam in SAM.SEL){
        Sys.sleep(0.01)
        tcltk::tkinsert(list.of.sam,"end",sam)
      }
      if(is.sam.sel==1)
        tcltk::tkselection.set(list.of.sam,0)
    }
    
    if(sum(refresh==3)){
      tcltk::tkgrid(labe.fill,row=3,column=0,pady=c(15,5))
      labe3c <- tcltk::tklabel(win.work,text=as.character(length(FAC)),font=font.top,justify="left",width=10)
      tcltk::tkgrid(labe3c,row=3,column=0,pady=c(15,5))
      if(length(FAC)==0)
        is.fac.sel <- 0
      # UPDATE FACTOR SCROLLBAR
      list.of.fac <- tcltk::tklistbox(win.work,height=7,width=62,selectmode="single")
      tcltk::tkgrid(list.of.fac,columnspan=3,row=4,column=0,padx=5,pady=c(0,10),sticky='n')
      # FILL IT WITH VARIABLE NAMES IN FAC
      for(fac in FAC){
        Sys.sleep(0.01)
        tcltk::tkinsert(list.of.fac,"end",fac)
      }
    }
    
    if(sum(refresh==4)){
      tcltk::tkgrid(labe.fill,row=3,column=3,pady=c(15,5))
      labe4c <- tcltk::tklabel(win.work,text=as.character(length(LEV[[FAC[1]]])),font=font.top,justify="left",width=10)
      tcltk::tkgrid(labe4c,row=3,column=3,pady=c(15,5))
      # UPDATE LINKED LEVELS SCROLLBAR
      list.of.lev <- tcltk::tklistbox(win.work,height=10,width=62,selectmode="single")
      tcltk::tkgrid(list.of.lev,columnspan=3,row=4,rowspan=2,column=3,padx=5,pady=c(0,10))
      if(length(FAC)==0){
        is.fac.sel <- 0
      }
      else
        # FILL IT WITH VARIABLE IN LEV
        for(lev in LEV[[FAC[1]]]){
          Sys.sleep(0.01)
          tcltk::tkinsert(list.of.lev,"end",lev)
        }
      if(is.lev.sel==1)
        tcltk::tkselection.set(list.of.lev,0)
      if(is.fac.sel==1)
        tcltk::tkselection.set(list.of.fac,0)
    }
    
    if(sum(refresh==2)){
      Sys.sleep(0.01)
      tcltk::tkgrid(labe.fill,row=0,column=3,pady=c(15,5))
      labe2c <- tcltk::tklabel(win.work,text=as.character(length(GEN)),font=font.top,justify="left",width=10)
      tcltk::tkgrid(labe2c,row=0,column=3,pady=c(15,5))
      if(length(GEN)==0)
        is.gen.sel <- 0
      # UPDATE GENES SCROLLBAR - JUST THE FIRST 100 SHOWN! - DO AT LAST
      list.of.gen <- tcltk::tklistbox(win.work,height=7,width=62,selectmode="single")
      tcltk::tkgrid(list.of.gen,columnspan=3,row=1,column=3,rowspan=1,padx=5,sticky='n')
      # FILL IT WITH VARIABLE NAMES IN GEN
      if(length(GEN)==0){
        refresh <- c()
        next
      }
      for(gen in GEN[1:min(length(GEN),25)]){
        Sys.sleep(0.01)
        tcltk::tkinsert(list.of.gen,"end",gen)
      }
      if(is.gen.sel==1)
        tcltk::tkselection.set(list.of.gen,0)
    }
    
    refresh <- c()
    
    # DIFFERENT MATRIX/DATA SELECTED
    # ...TRY IS TO AVOID ERROR MESSAGES AFTER DESTROYING THE WINDOW
    fac.sel <- try(as.numeric(tcltk::tkcurselection(list.of.fac)),silent=TRUE)
    lev.sel <- try(as.numeric(tcltk::tkcurselection(list.of.lev)),silent=TRUE)
    sam.sel <- try(as.numeric(tcltk::tkcurselection(list.of.sam)),silent=TRUE)
    gen.sel <- try(as.numeric(tcltk::tkcurselection(list.of.gen)),silent=TRUE)
    
    # SELECTED SAMPLE
    if(is.numeric(sam.sel)&length(sam.sel)>0){
      if(sam.sel>0){
        refresh <- c(1)
        # MOVE AT THE TOP WHEN SELECTED
        index <- which(SAM==SAM.SEL[sam.sel+1])
        SAM.OLD <- SAM
        SAM[1]<-SAM[index]
        SAM[2:length(SAM)]<-SAM.OLD[-index]
        SAM.SEL.OLD <- SAM.SEL
        SAM.SEL[1]<-SAM.SEL[sam.sel+1]
        SAM.SEL[2:length(SAM.SEL)]<-SAM.SEL.OLD[-(sam.sel+1)]
      }
      # NO LEVELS, SAMPLES, GENES ARE SELECTED ANYMORE
      is.sam.sel <- 1
      is.lev.sel <- 0
      is.fac.sel <- 0
      is.gen.sel <- 0
    }
    
    # SELECTED GENE
    if(is.numeric(gen.sel)&length(gen.sel)>0){
      if(gen.sel>0){
        refresh <- c(2)
        # MOVE AT THE TOP WHEN SELECTED
        GEN.OLD <- GEN
        GEN[1]<-GEN[gen.sel+1]
        GEN[2:length(GEN)]<-GEN.OLD[-(gen.sel+1)]
      }
      # NO LEVELS, SAMPLES, GENES ARE SELECTED ANYMORE
      is.gen.sel <- 1
      is.lev.sel <- 0
      is.sam.sel <- 0
      is.fac.sel <- 0
    }
    
    # SELECTED FACTOR
    if(is.numeric(fac.sel)&length(fac.sel)>0){
      if(fac.sel>0){
        refresh <- c(3,4)
        # MOVE AT THE TOP WHEN SELECTED
        FAC.OLD <- FAC
        FAC[1]<-FAC[fac.sel+1]
        FAC[2:length(FAC)]<-FAC.OLD[-(fac.sel+1)]
      }
      if(length(SAM.SEL)!=length(SAM)){
        # RETRIEVE ALL SAMPLES WHEN YOU CHANGE FACTOR
        SAM.SEL <- SAM
        # TEXT ISSUE
        t <- l
        refresh <- c(1,refresh)
      }
      # NO LEVELS, SAMPLES, GENES ARE SELECTED ANYMORE
      is.fac.sel <- 1
      is.lev.sel <- 0
      is.sam.sel <- 0
      is.gen.sel <- 0
    }
    
    # SELECTED LEVEL
    if(is.numeric(lev.sel)&length(lev.sel)>0){
      if(lev.sel){
        refresh <- c(1,4)
        # MOVE AT THE TOP WHEN SELECTED
        LEV.OLD <- LEV[[FAC[1]]]
        LEV[[FAC[1]]][1]<-LEV[[FAC[1]]][lev.sel+1]
        LEV[[FAC[1]]][2:length(LEV.OLD)]<-LEV.OLD[-(lev.sel+1)]
      }
      if(is.lev.sel==0){
        # RETRIEVE ALL SAMPLES WHEN YOU CHANGE FACTOR
        SAM.SEL <- SAM
        # TEXT ISSUE
        t <- l
        refresh <- c(1,4)
      }
      # NO LEVELS, SAMPLES, GENES ARE SELECTED ANYMORE
      is.lev.sel <- 1
      is.fac.sel <- 0
      is.sam.sel <- 0
      is.gen.sel <- 0
    }
    
    ###########################################################################
    
    if(task==1){
      sampleSelect(env,env0)
      refresh <- c(1,4)
      tcltk::tktitle(win.work)<-mat.name
      l <- length(SAM)
      t <- l
      SAM.SEL <- SAM
      is.lev.sel <- 0
      is.fac.sel <- 1
      task <- 0
    }
    if(task==2){
      geneSelect(env,env0)
      refresh <- c(2)
      tcltk::tktitle(win.work)<-mat.name
      task <- 0
    }
    if(task==3){
      task <- 0
      getFactor(env,env0)
      data <- get(mat.name,envir=.GlobalEnv)
      refresh <- c(3,4)
    }
    if(task==4){
      t <- l
      SAM.SEL <- SAM
      refresh <- c(1,3,4)
      renameLevel(env)
      task <- 0
    }
    if(task==5){
      searchGENE(env)
      task <- 0
    }
    if(task==6){
      refresh <- c(3,4)
      deleteFactor(env)
      task <- 0
    }
  }
  # END OF FUNCTION
  tcltk::tkdestroy(win.work)
}



#' @title deleteData
#' 
#' 
#' @export
deleteData<-function(env0){
  
  is.mat.sel<-get('is.mat.sel',envir=env0)
  GLOB<-get('GLOB',envir=env0)
  GSE<-get('GSE',envir=env0)
  gse<-GSE[1]
  MAT<-get('MAT',envir=env0)
  
  ##########################################################
  
  # NO EXPRESSION DATA SELECTED
  if(is.null(gse)){
    tcltk::tkmessageBox(message='No data available!',icon="error",type="ok")
    return()
  }
  if(length(MAT[[gse]])==0){
    tcltk::tkmessageBox(message='No data available!',icon="error",type="ok")
    return()
  }
  if(is.mat.sel==0){
    tcltk::tkmessageBox(message='No data selected!',icon="error",type="ok")
    return()
  }
  delete.name<-MAT[[gse]][1]
  
  ##########################################################
  
  # CHECK IF YOU REALLY WANT TO DELETE THE SERIES MATRIX
  answer<-tcltk::tkmessageBox(message=paste("Do you want to delete ",delete.name,'?',sep=''),
                       icon = "warning", type = "yesno", default = "yes")
  answer<-as.character(tcltk::tclvalue(answer))
  if(answer=='no')
    return()
  
  ##########################################################
  
  # PROCEED - REMOVE THE EXPRESSION DATA
  remove(list=c(delete.name),envir=.GlobalEnv)
  # REMOVE THE VARIABLE NAME FROM THE RELATED LISTS
  for(m in GSE){
    index<-which(MAT[[m]]==delete.name)
    if(length(index)>0)
      MAT[[m]]<-MAT[[m]][-index]
  }
  # necessary if the same data is shared by multiple matrices
  GLOB<-GLOB[-which(GLOB==delete.name)]
  # UPLOAD ALL LISTS TO HIGHER ENVIRONMENT
  assign('GLOB',GLOB,envir=env0)
  assign('MAT',MAT,envir=env0)
  assign('GSE',GSE,envir=env0)
  # MOVE FOCUS TO gse.sel
  assign('is.gse.sel',1,envir=env0)
  assign('is.mat.sel',0,envir=env0)
}

#' @title scaleData
#' 
#' 
scaleData <- function(env0){
  is.mat.sel<-get('is.mat.sel',envir = env0)
  # NO DATA SELECTED
  if(is.mat.sel==0){
    tcltk::tkmessageBox(message='No data selected!',icon="error",type="ok")
    return()
  }
  MAT<-get('MAT',envir = env0)
  GSE<-get('GSE',envir = env0)
  # SCALE DATA - RETRIEVE OLD EXPRESSION-DATA
  mat <- get(MAT[[GSE[1]]][1],envir=.GlobalEnv)
  # RETRIEVE THE GSE
  gse <- get(GSE[1],envir=.GlobalEnv)
  # GET A NEW EXPRESSION-DATA, SAME AS BEFORE
  mat.new <- exprs(gse)
  # KEEP JUST THE RIGHT ROWS AND COLUMN
  rows.keep <- intersect(rownames(mat),rownames(mat.new))
  cols.keep <- intersect(colnames(mat),colnames(mat.new))
  mat.new <- mat.new[rows.keep,cols.keep]
  # CHECK THE CLASS OF THIS OBJECT: MUST BE NUMERIC MATRIX TO WORK
  cl <- class(mat.new)
  mat.new <- try(scale(mat.new),silent = TRUE)
  if(class(mat.new)!=cl){
    tcltk::tkmessageBox(message='Scaling could not be accomplished!',icon="error",type="ok")
    return()
  }
  # ALL THIS MESS, JUST BECAUSE THERE CAN BE FACTORS ASSOCIATED TO DATA!
  GEN <- rows.keep
  # FACTOR ROWS
  FAC <- setdiff(rownames(mat),rownames(mat.new))
  # RETRIEVE FACTORS
  mat <- rbind(mat.new[GEN,],mat[FAC,])
  # EXPORT DATA TO GLOBAL ENVIRONMENT
  assign(MAT[[GSE[1]]][1],mat,envir=.GlobalEnv)
  tcltk::tkmessageBox(message='Done!',icon="info",type="ok")
}